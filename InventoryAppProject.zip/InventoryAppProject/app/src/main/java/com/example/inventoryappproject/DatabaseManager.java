package com.example.inventoryappproject;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseManager {
    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DatabaseManager(Context c) {
        context = c;
    }

    public DatabaseManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    // User table methods
    public long insertUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        return database.insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    public boolean isValidUser(String username, String password) {
        String[] columns = { DatabaseHelper.COLUMN_ID };
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };

        Cursor cursor = database.query(
                DatabaseHelper.TABLE_USERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean isValid = cursor.moveToFirst();
        cursor.close();
        return isValid;
    }

    // Inventory table methods
    public long insertInventoryItem(String itemName, String itemDescription, int itemQuantity) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_ITEM_DESCRIPTION, itemDescription);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, itemQuantity);

        return database.insert(DatabaseHelper.TABLE_INVENTORY, null, values);
    }

    public Cursor getAllInventoryItems() {
        return database.query(
                DatabaseHelper.TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                null
        );
    }

    // Add more methods as needed for updating and deleting inventory items

    // ...
}

