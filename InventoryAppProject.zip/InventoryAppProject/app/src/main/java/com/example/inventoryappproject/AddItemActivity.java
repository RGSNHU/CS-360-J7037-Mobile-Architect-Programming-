package com.example.inventoryappproject;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class AddItemActivity extends AppCompatActivity {
    private EditText editTextItemName;
    private EditText editTextItemDescription;
    private EditText editTextItemQuantity;
    private Button buttonSave;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize UI elements
        editTextItemName = findViewById(R.id.editTextItemName);
        editTextItemDescription = findViewById(R.id.editTextItemDescription);
        editTextItemQuantity = findViewById(R.id.editTextItemQuantity);
        buttonSave = findViewById(R.id.buttonSave);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set up the click listener for the Save button
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveItemToDatabase();
            }
        });
    }

    private void saveItemToDatabase() {
        // Get item details from the input fields
        String itemName = editTextItemName.getText().toString();
        String itemDescription = editTextItemDescription.getText().toString();
        int itemQuantity = Integer.parseInt(editTextItemQuantity.getText().toString());

        // Get a writable database
        SQLiteDatabase database = databaseHelper.getWritableDatabase();

        // Create a ContentValues object to store the item details
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_ITEM_DESCRIPTION, itemDescription);
        values.put(DatabaseHelper.COLUMN_ITEM_QUANTITY, itemQuantity);

        // Insert the item details into the database
        long newRowId = database.insert(DatabaseHelper.TABLE_INVENTORY, null, values);

        if (newRowId != -1) {
            // Data was saved successfully
            Toast.makeText(AddItemActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();

            // Set up an Intent to send data back to InventoryActivity
            Intent intent = new Intent();
            intent.putExtra("data_key", "Data you want to send back to InventoryActivity");

            // Set the result to RESULT_OK and include the intent
            setResult(RESULT_OK, intent);

            // Finish the AddItemActivity
            finish();
        } else {
            // Data saving failed
            Toast.makeText(AddItemActivity.this, "Error adding item", Toast.LENGTH_SHORT).show();
        }

        // Close the database
        database.close();
    }
}

