package com.example.inventoryappproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    private GridView dataGridView;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.databasegrid);

        databaseHelper = new DatabaseHelper(this);
        database = databaseHelper.getWritableDatabase();

        dataGridView = findViewById(R.id.dataGridView);
        addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open the AddItemActivity when the "Add Data" button is pressed
                Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
                startActivityForResult(intent, YOUR_REQUEST_CODE);
            }
        });

        // Read and display existing items
        refreshData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == YOUR_REQUEST_CODE) {
                // Handle the data returned from AddItemActivity
                String receivedData = data.getStringExtra("data_key");
                // Refresh your data as needed
            }
        }
    }

    private void refreshData() {
        List<InventoryItem> items = getInventoryItems();
        InventoryItemAdapter adapter = new InventoryItemAdapter(this, items);
        dataGridView.setAdapter(adapter);
    }

    private List<InventoryItem> getInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") int itemId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_INVENTORY_ID));
                @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_NAME));
                @SuppressLint("Range") String itemDescription = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_DESCRIPTION));
                @SuppressLint("Range") int itemQuantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_QUANTITY));

                InventoryItem item = new InventoryItem(itemId, itemName, itemDescription, itemQuantity);
                items.add(item);
            }

            cursor.close();
        }
        return items;
    }


    private static final int YOUR_REQUEST_CODE = 123;
}


