package com.example.inventoryappproject;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;
import android.content.ContentValues;


public class LoginActivity extends AppCompatActivity {
    private EditText usernameField, passwordField;
    private Button loginButton, createAccountButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.logInButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        dbHelper = new DatabaseHelper(this);

        // Set click listeners for buttons
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameField.getText().toString();
                String password = passwordField.getText().toString();

                // Check if the user is valid
                if (isValidUser(username, password)) {
                    // Valid user, navigate to the main screen
                    navigateToMainScreen();
                } else {
                    // Invalid user, show an error message
                    showError("Invalid username or password");
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameField.getText().toString();
                String password = passwordField.getText().toString();

                // Check if either field is blank
                if (username.isEmpty() || password.isEmpty()) {
                    showError("Both username and password are required");
                } else {
                    // Check if the account already exists
                    if (isAccountExists(username)) {
                        // Account already exists, show a message
                        showError("Account already created.");
                    } else {
                        // Account doesn't exist, save it to the database and navigate to the main screen
                        saveAccountToDatabase(username, password);
                    }
                }
            }
        });
    }

    private void saveAccountToDatabase(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);
        db.close();

        if (newRowId != -1) {
            // Account added successfully
            navigateToMainScreen();
        } else {
            showError("Error creating account");
        }
    }

    private boolean isValidUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define the columns you want to retrieve from the users table
        String[] projection = {DatabaseHelper.COLUMN_USERNAME, DatabaseHelper.COLUMN_PASSWORD};

        // Define the selection criteria
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ? AND " + DatabaseHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        // Query the database
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, projection, selection, selectionArgs, null, null, null);

        // Check if a row with the given username and password exists
        boolean isValid = cursor.getCount() > 0;

        // Close the cursor and the database
        cursor.close();
        db.close();

        return isValid;
    }

    private boolean isAccountExists(String username) {
        // Add logic to check if the account already exists
        // You can perform a database query here to check if the username exists in your database
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_USERNAME};
        String selection = DatabaseHelper.COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, projection, selection, selectionArgs, null, null, null);
        boolean accountExists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return accountExists;
    }

    private void navigateToMainScreen() {
        // Navigation to the main screen...
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        startActivity(intent);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}


