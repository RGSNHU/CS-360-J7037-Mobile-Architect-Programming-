package com.example.inventoryappproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;

    private Button requestPermissionButton;
    private TextView permissionStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notificationscreen);

        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        permissionStatusTextView = findViewById(R.id.permissionStatusTextView);

        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestSMSPermission();
            }
        });
    }

    private void requestSMSPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            permissionStatusTextView.setText("Permission granted. You can send SMS messages.");
        } else {
            // Permission not granted, request it
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults); // Add this line

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                permissionStatusTextView.setText("Permission granted. You can send SMS messages.");
                sendSMS();
            } else {
                // Permission denied
                permissionStatusTextView.setText("Permission denied. SMS feature disabled.");
            }
        }
    }


    private void sendSMS() {
        // Implement your SMS sending logic here
        String phoneNumber = "1234567890";
        String message = "This is a test SMS message.";
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show();
    }
}

