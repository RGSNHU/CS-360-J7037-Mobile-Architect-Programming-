package com.example.inventoryappproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;

public class InventoryItemAdapter extends BaseAdapter {
    private Context context;
    private List<InventoryItem> items;

    public InventoryItemAdapter(Context context, List<InventoryItem> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.databasegrid, parent, false);
        }

        InventoryItem item = items.get(position);

        TextView nameTextView = convertView.findViewById(R.id.nameTextView);
        TextView descriptionTextView = convertView.findViewById(R.id.descriptionTextView);
        TextView quantityTextView = convertView.findViewById(R.id.quantityTextView);

        nameTextView.setText(item.getName());
        descriptionTextView.setText(item.getDescription());
        quantityTextView.setText(String.valueOf(item.getQuantity()));

        return convertView;
    }
}

